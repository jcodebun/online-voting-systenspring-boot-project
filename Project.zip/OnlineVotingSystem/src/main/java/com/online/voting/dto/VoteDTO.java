package com.online.voting.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "vote")
@Setter
@Getter
public class VoteDTO extends BaseDTO{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "votercardnumber",length = 200)
	private String votercardnumber;
	@Column(name = "Vote",length = 200)
	private String vote;
	
	private long userid;

	@Override
	public String getKey() {
		return null;
	}

	@Override
	public String getValue() {
		return null;
	}
	
	

}
